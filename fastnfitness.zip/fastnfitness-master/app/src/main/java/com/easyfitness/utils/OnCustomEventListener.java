package com.easyfitness.utils;

public interface OnCustomEventListener {
    void onEvent(String eventName);
}
